package com.vit.service;

import com.vit.model.CartItem;

public interface CartItemService {
	
	public CartItem createCartItem(CartItem item);

}
