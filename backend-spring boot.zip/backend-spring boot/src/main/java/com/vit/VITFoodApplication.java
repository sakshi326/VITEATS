package com.vit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VITFoodApplication {

	public static void main(String[] args) {
		SpringApplication.run(VITFoodApplication.class, args);
	}

}
