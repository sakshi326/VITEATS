package com.vit.request;

import lombok.Data;

@Data
public class Ingredient {
	
	private String categoryName;
	private String ingredientName;
}
