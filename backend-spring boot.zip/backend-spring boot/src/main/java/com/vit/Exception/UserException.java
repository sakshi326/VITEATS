package com.vit.Exception;

public class UserException extends Exception {
	
	
	public UserException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
