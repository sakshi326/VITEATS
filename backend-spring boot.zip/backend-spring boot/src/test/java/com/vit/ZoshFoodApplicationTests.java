package com.vit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VITFoodApplicationTests {

	@Test
	void contextLoads() {
	}

}
